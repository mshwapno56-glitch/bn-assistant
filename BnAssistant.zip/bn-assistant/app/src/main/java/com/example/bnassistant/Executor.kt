package com.example.bnassistant

import android.Manifest
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** কমান্ড চালায় এবং ফলাফলের একটা ছোট বাংলা বার্তা ফেরত দেয়। */
object Executor {

    @Volatile
    private var torchOn = false

    private const val WA = "com.whatsapp"
    private const val WA_BUSINESS = "com.whatsapp.w4b"

    /** বাংলাদেশের নম্বরে 880 কোড বসায়। হোয়াটসঅ্যাপের লিংকে + ছাড়া শুধু অঙ্ক লাগে। */
    private fun waNumber(raw: String): String? {
        var d = raw.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.removePrefix("00")
        d = when {
            d.startsWith("880") -> d
            d.startsWith("0") && d.length == 11 -> "880" + d.substring(1)
            d.length == 10 && d.startsWith("1") -> "880$d"
            else -> d
        }
        return if (d.length in 8..15) d else null
    }

    private fun granted(ctx: Context, perm: String) =
        ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

    private fun launch(ctx: Context, intent: Intent) {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun run(ctx: Context, cmd: Command, match: ContactMatch? = null): String =
        try {
            runInternal(ctx, cmd, match)
        } catch (e: SecurityException) {
            "পারমিশন নেই: ${e.message}"
        } catch (e: Exception) {
            "কাজটা করা যায়নি: ${e.message}"
        }

    private fun runInternal(ctx: Context, cmd: Command, match: ContactMatch?): String {
        when (cmd.type) {
            ActionType.CALL -> {
                val m = match ?: return "কন্টাক্ট পাইনি"
                if (!granted(ctx, Manifest.permission.CALL_PHONE)) return "কল করার পারমিশন নেই"
                val uri = Uri.fromParts("tel", m.number, null)
                try {
                    ctx.getSystemService(TelecomManager::class.java).placeCall(uri, Bundle())
                } catch (e: Exception) {
                    launch(ctx, Intent(Intent.ACTION_CALL, uri))
                }
                return "${m.name}-কে কল করা হচ্ছে"
            }

            ActionType.SMS -> {
                val m = match ?: return "কন্টাক্ট পাইনি"
                if (!granted(ctx, Manifest.permission.SEND_SMS)) return "SMS পাঠানোর পারমিশন নেই"
                val sms: SmsManager = if (Build.VERSION.SDK_INT >= 31) {
                    ctx.getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    SmsManager.getDefault()
                }
                sms.sendMultipartTextMessage(m.number, null, sms.divideMessage(cmd.message), null, null)
                return "${m.name}-কে মেসেজ পাঠানো হয়েছে"
            }

            ActionType.APP_MSG -> {
                val m = match ?: return "কন্টাক্ট পাইনি"
                val km = ctx.getSystemService(KeyguardManager::class.java)
                if (km != null && km.isKeyguardLocked) {
                    return "ফোন লক করা। আনলক করে আবার বলুন (লক স্ক্রিনে হোয়াটসঅ্যাপ খোলা যায় না)"
                }
                val pm = ctx.packageManager
                val order = if (cmd.arg == "whatsapp_business") listOf(WA_BUSINESS, WA) else listOf(WA, WA_BUSINESS)
                val pkg = order.firstOrNull { pm.getLaunchIntentForPackage(it) != null }
                    ?: return "হোয়াটসঅ্যাপ ইনস্টল নেই"
                val num = waNumber(m.number) ?: return "নম্বরটা ঠিক নয়: ${m.number}"
                val uri = Uri.parse("https://wa.me/$num?text=${Uri.encode(cmd.message)}")
                launch(ctx, Intent(Intent.ACTION_VIEW, uri).setPackage(pkg))
                return if (AssistAccessibilityService.isEnabled()) {
                    AssistAccessibilityService.sendWhatsApp(pkg)
                    "${m.name}-কে হোয়াটসঅ্যাপে পাঠানো হচ্ছে"
                } else {
                    "মেসেজ লিখে রেখেছি। অ্যাক্সেসিবিলিটি চালু নেই, তাই নিজে Send চাপুন"
                }
            }

            ActionType.OPEN_APP -> {
                val app = AppFinder.find(ctx, cmd.name, cmd.nameEn)
                    ?: return "\"${cmd.name.ifEmpty { cmd.nameEn }}\" নামে অ্যাপ পাইনি"
                launch(ctx, app.intent)
                return "${app.label} খোলা হচ্ছে"
            }

            ActionType.TORCH -> {
                val cm = ctx.getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.firstOrNull {
                    val c = cm.getCameraCharacteristics(it)
                    c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                        c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                } ?: return "এই ফোনে টর্চ পাইনি"
                val on = when (cmd.arg) {
                    "on" -> true
                    "off" -> false
                    else -> !torchOn
                }
                cm.setTorchMode(id, on)
                torchOn = on
                return if (on) "টর্চ জ্বলছে" else "টর্চ নিভেছে"
            }

            ActionType.VOLUME -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                val s = AudioManager.STREAM_MUSIC
                when (cmd.arg) {
                    "up" -> repeat(3) {
                        am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, if (it == 0) AudioManager.FLAG_SHOW_UI else 0)
                    }
                    "down" -> repeat(3) {
                        am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, if (it == 0) AudioManager.FLAG_SHOW_UI else 0)
                    }
                    "mute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                    "max" -> am.setStreamVolume(s, am.getStreamMaxVolume(s), AudioManager.FLAG_SHOW_UI)
                    else -> return "ভলিউম নিয়ে কী করব বুঝিনি"
                }
                return "ভলিউম ঠিক করা হয়েছে"
            }

            ActionType.MEDIA -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                val code = when (cmd.arg) {
                    "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
                    "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                }
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
                return "ঠিক আছে"
            }

            ActionType.ALARM -> {
                launch(
                    ctx,
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, cmd.hour)
                        .putExtra(AlarmClock.EXTRA_MINUTES, cmd.minute)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
                return "অ্যালার্ম দেওয়া হলো %d:%02d".format(cmd.hour, cmd.minute)
            }

            ActionType.TIMER -> {
                launch(
                    ctx,
                    Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, cmd.seconds)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
                return "টাইমার চালু হলো"
            }

            ActionType.ANSWER_CALL -> {
                if (!granted(ctx, Manifest.permission.ANSWER_PHONE_CALLS)) return "কল ধরার পারমিশন নেই"
                ctx.getSystemService(TelecomManager::class.java).acceptRingingCall()
                return "কল ধরা হয়েছে"
            }

            ActionType.REJECT_CALL -> {
                if (!granted(ctx, Manifest.permission.ANSWER_PHONE_CALLS)) return "কল কাটার পারমিশন নেই"
                if (Build.VERSION.SDK_INT < 28) return "এই ফোনে কল কাটা সম্ভব না"
                ctx.getSystemService(TelecomManager::class.java).endCall()
                return "কল কেটে দেওয়া হয়েছে"
            }

            ActionType.GLOBAL -> {
                if (!AssistAccessibilityService.isEnabled()) return "অ্যাক্সেসিবিলিটি চালু নেই"
                return if (AssistAccessibilityService.global(cmd.arg)) "ঠিক আছে" else "কাজটা করা যায়নি"
            }

            ActionType.CLICK -> {
                if (!AssistAccessibilityService.isEnabled()) return "অ্যাক্সেসিবিলিটি চালু নেই"
                return if (AssistAccessibilityService.clickText(cmd.message)) "\"${cmd.message}\"-এ ট্যাপ করা হয়েছে"
                else "স্ক্রিনে \"${cmd.message}\" পাইনি"
            }

            ActionType.TYPE -> {
                if (!AssistAccessibilityService.isEnabled()) return "অ্যাক্সেসিবিলিটি চালু নেই"
                return if (AssistAccessibilityService.typeText(cmd.message)) "লেখা হয়েছে"
                else "কোথায় লিখব বুঝিনি, আগে লেখার ঘরে ট্যাপ করুন"
            }

            ActionType.TIME -> {
                val f = SimpleDateFormat("h:mm a", Locale("bn", "BD"))
                return "এখন সময় ${f.format(Date())}"
            }

            ActionType.SETTINGS -> {
                val action = when (cmd.arg) {
                    "wifi" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "data" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_DATA_ROAMING_SETTINGS
                    else -> Settings.ACTION_SETTINGS
                }
                launch(ctx, Intent(action))
                return "সেটিংস খুলেছি, ওখানে চালু/বন্ধ করে নিন"
            }

            ActionType.UNKNOWN -> return "বুঝতে পারিনি"
        }
        @Suppress("UNREACHABLE_CODE")
        return "বুঝতে পারিনি"
    }
}
