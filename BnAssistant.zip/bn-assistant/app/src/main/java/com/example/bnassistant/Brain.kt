package com.example.bnassistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class Resolved(val cmd: Command, val matches: List<ContactMatch>)

/** কথা → কমান্ড (+ কন্টাক্ট)। অ্যাক্টিভিটি ও ব্যাকগ্রাউন্ড সার্ভিস দুটোই এটা ব্যবহার করে। */
object Brain {

    fun keyword(alternatives: List<String>): Command? =
        alternatives.asSequence()
            .map { CommandParser.parse(it) }
            .firstOrNull { it.type != ActionType.UNKNOWN }

    private suspend fun ask(apiKey: String, spoken: String, status: (String) -> Unit): Command? {
        if (apiKey.isEmpty()) {
            status("কমান্ড বুঝতে পারিনি। অ্যাপে Claude API key দিলে আরও ভালো বুঝবে।")
            return null
        }
        status("Claude-কে জিজ্ঞেস করছি…")
        return try {
            ClaudeClient.parse(apiKey, spoken).takeIf { it.type != ActionType.UNKNOWN }
        } catch (e: Exception) {
            status("Claude ত্রুটি: ${e.message}")
            null
        }
    }

    private suspend fun findContacts(
        ctx: Context,
        cmd: Command,
        status: (String) -> Unit
    ): List<ContactMatch> {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            status("কন্টাক্ট পড়ার পারমিশন দিন।")
            return emptyList()
        }
        return withContext(Dispatchers.IO) {
            try {
                ContactFinder.find(ctx, cmd.name, cmd.nameEn)
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    /** null = কমান্ড বোঝা যায়নি। কল/SMS হলে matches-এ মিলে যাওয়া কন্টাক্ট থাকে (খালিও হতে পারে)। */
    suspend fun resolve(
        ctx: Context,
        alternatives: List<String>,
        apiKey: String,
        status: (String) -> Unit
    ): Resolved? {
        var cmd = keyword(alternatives)
        var viaClaude = false
        if (cmd == null) {
            cmd = ask(apiKey, alternatives.first(), status) ?: return null
            viaClaude = true
        }

        var matches = if (cmd.needsContact) findContacts(ctx, cmd, status) else emptyList()

        // কীওয়ার্ডে নাম মেলেনি — Claude নামটা ঠিক করে দিতে পারে
        if (cmd.needsContact && matches.isEmpty() && !viaClaude && apiKey.isNotEmpty()) {
            status("কন্টাক্টে পাইনি, Claude-এর সাহায্য নিচ্ছি…")
            val retry = ask(apiKey, alternatives.first(), status)
            if (retry != null) {
                cmd = retry
                if (retry.needsContact) matches = findContacts(ctx, retry, status)
            }
        }
        return Resolved(cmd, matches)
    }
}
