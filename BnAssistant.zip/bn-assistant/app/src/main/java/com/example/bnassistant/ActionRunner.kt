package com.example.bnassistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager

object ActionRunner {

    /** সরাসরি কল দেয় (CALL_PHONE পারমিশন লাগে)। */
    fun call(context: Context, number: String) {
        val intent = Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    /** সরাসরি SMS পাঠায় (SEND_SMS পারমিশন লাগে)। লম্বা মেসেজ নিজে ভেঙে পাঠায়। */
    fun sendSms(context: Context, number: String, message: String) {
        val sms: SmsManager = if (Build.VERSION.SDK_INT >= 31) {
            context.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getDefault()
        }
        val parts = sms.divideMessage(message)
        sms.sendMultipartTextMessage(number, null, parts, null, null)
    }
}
