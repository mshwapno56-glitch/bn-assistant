package com.example.bnassistant

enum class ActionType { CALL, SMS, UNKNOWN }

/**
 * একটা বোঝা-হয়ে-যাওয়া কমান্ড।
 * name    = বাংলায় বলা নাম (যেমন "রহিম")
 * nameEn  = ইংরেজি বানান (Claude দিলে; কন্টাক্ট ইংরেজিতে সেভ থাকলে কাজে লাগে)
 * message = শুধু SMS-এর জন্য, পাঠানোর লেখা
 */
data class Command(
    val type: ActionType,
    val name: String = "",
    val nameEn: String = "",
    val message: String = ""
)
