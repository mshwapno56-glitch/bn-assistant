package com.example.bnassistant

enum class ActionType {
    CALL, SMS, OPEN_APP, TORCH, VOLUME, MEDIA, ALARM, TIMER,
    ANSWER_CALL, REJECT_CALL, GLOBAL, CLICK, TYPE, TIME, SETTINGS, UNKNOWN
}

/**
 * একটা বোঝা-হয়ে-যাওয়া কমান্ড।
 * name/nameEn = কন্টাক্ট বা অ্যাপের নাম (বাংলা / ইংরেজি বানান)
 * message     = SMS-এর লেখা, অথবা CLICK/TYPE-এর লেখা
 * arg         = উপ-কাজ: torch=on/off/toggle, volume=up/down/mute/max,
 *               media=play/pause/next/prev, global=home/back/recents/notifications/lock/screenshot,
 *               settings=wifi/bluetooth/data
 * hour/minute = অ্যালার্মের সময়, seconds = টাইমারের দৈর্ঘ্য
 */
data class Command(
    val type: ActionType,
    val name: String = "",
    val nameEn: String = "",
    val message: String = "",
    val arg: String = "",
    val hour: Int = -1,
    val minute: Int = 0,
    val seconds: Int = 0
) {
    val needsContact: Boolean
        get() = type == ActionType.CALL || type == ActionType.SMS
}
