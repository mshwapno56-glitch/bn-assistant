package com.example.bnassistant

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * কীওয়ার্ডে না বুঝলে Claude API-কে দিয়ে বাংলা বাক্য থেকে কমান্ড বের করানো হয়।
 * শুধু আপনার বলা বাক্যটুকু পাঠানো হয় — কন্টাক্ট লিস্ট বা অন্য কিছু পাঠানো হয় না।
 */
object ClaudeClient {

    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-haiku-5-5"

    private val SYSTEM_PROMPT = """
        You convert a Bengali (Bangla) voice command for a phone assistant into JSON.
        The text comes from speech recognition, so it may contain small mistakes.
        Reply with ONLY one JSON object and nothing else:
        {"action":"...","name":"","name_en":"","message":"","arg":"","hour":-1,"minute":0,"seconds":0}
        action is one of:
        - call: phone a contact. name = contact name in Bangla without the suffix কে; name_en = English transliteration.
        - sms: text a contact. name, name_en as above; message = the text to send, written the way the user would send it.
        - open_app: open an app. name = app name as spoken; name_en = the app's English name.
        - torch: arg = on | off | toggle.
        - volume: arg = up | down | mute | max.
        - media: arg = play | pause | next | prev.
        - alarm: hour (0-23) and minute.
        - timer: seconds.
        - answer_call, reject_call: for an incoming call.
        - global: arg = home | back | recents | notifications | lock | screenshot.
        - click: message = the on-screen text to tap.
        - type: message = the text to type into the focused field.
        - time: the user asks the current time.
        - settings: arg = wifi | bluetooth | data.
        - unknown: anything else.
        Use empty strings / defaults for fields that do not apply.
        Examples:
        Input: আম্মুকে ফোন করো
        Output: {"action":"call","name":"আম্মু","name_en":"Ammu","message":"","arg":"","hour":-1,"minute":0,"seconds":0}
        Input: রহিমকে বলে দাও আমি আধা ঘণ্টা পরে আসছি
        Output: {"action":"sms","name":"রহিম","name_en":"Rahim","message":"আমি আধা ঘণ্টা পরে আসছি","arg":"","hour":-1,"minute":0,"seconds":0}
        Input: রাত সাড়ে দশটায় ঘুম থেকে ডেকে দিও
        Output: {"action":"alarm","name":"","name_en":"","message":"","arg":"","hour":22,"minute":30,"seconds":0}
    """.trimIndent()

    /** ফেরত দেয় Command; বুঝতে না পারলে type = UNKNOWN। নেটওয়ার্ক/API ভুল হলে IOException। */
    suspend fun parse(apiKey: String, spoken: String): Command = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 300)
            .put("system", SYSTEM_PROMPT)
            .put(
                "messages",
                JSONArray().put(JSONObject().put("role", "user").put("content", spoken))
            )

        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 25_000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("anthropic-version", "2023-06-01")
        }

        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw IOException("HTTP $code ${err.take(200)}")
            }

            val response = conn.inputStream.bufferedReader().use { it.readText() }
            val text = JSONObject(response)
                .getJSONArray("content")
                .getJSONObject(0)
                .getString("text")

            toCommand(text)
        } finally {
            conn.disconnect()
        }
    }

    private fun toCommand(modelText: String): Command {
        val start = modelText.indexOf('{')
        val end = modelText.lastIndexOf('}')
        if (start < 0 || end <= start) return Command(ActionType.UNKNOWN)

        val json = try {
            JSONObject(modelText.substring(start, end + 1))
        } catch (e: Exception) {
            return Command(ActionType.UNKNOWN)
        }

        val type = when (json.optString("action").lowercase()) {
            "call" -> ActionType.CALL
            "sms" -> ActionType.SMS
            "open_app" -> ActionType.OPEN_APP
            "torch" -> ActionType.TORCH
            "volume" -> ActionType.VOLUME
            "media" -> ActionType.MEDIA
            "alarm" -> ActionType.ALARM
            "timer" -> ActionType.TIMER
            "answer_call" -> ActionType.ANSWER_CALL
            "reject_call" -> ActionType.REJECT_CALL
            "global" -> ActionType.GLOBAL
            "click" -> ActionType.CLICK
            "type" -> ActionType.TYPE
            "time" -> ActionType.TIME
            "settings" -> ActionType.SETTINGS
            else -> ActionType.UNKNOWN
        }
        val cmd = Command(
            type = type,
            name = json.optString("name").trim(),
            nameEn = json.optString("name_en").trim(),
            message = json.optString("message").trim(),
            arg = json.optString("arg").trim().lowercase(),
            hour = json.optInt("hour", -1),
            minute = json.optInt("minute", 0),
            seconds = json.optInt("seconds", 0)
        )

        // অসম্পূর্ণ উত্তর বাদ
        val valid = when (type) {
            ActionType.CALL, ActionType.SMS -> cmd.name.isNotEmpty()
            ActionType.OPEN_APP -> cmd.name.isNotEmpty() || cmd.nameEn.isNotEmpty()
            ActionType.ALARM -> cmd.hour in 0..23 && cmd.minute in 0..59
            ActionType.TIMER -> cmd.seconds > 0
            ActionType.CLICK, ActionType.TYPE -> cmd.message.isNotEmpty()
            ActionType.UNKNOWN -> false
            else -> true
        }
        return if (valid) cmd else Command(ActionType.UNKNOWN)
    }
}
