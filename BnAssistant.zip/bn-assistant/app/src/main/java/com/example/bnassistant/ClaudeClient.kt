package com.example.bnassistant

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * কীওয়ার্ডে না বুঝলে Claude API-কে দিয়ে বাংলা বাক্য থেকে কমান্ড বের করানো হয়।
 * শুধু আপনার বলা বাক্যটুকু পাঠানো হয় — কন্টাক্ট লিস্ট কখনো পাঠানো হয় না।
 */
object ClaudeClient {

    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-haiku-5-5"

    private val SYSTEM_PROMPT = """
        You convert a Bengali (Bangla) voice command for a phone assistant into JSON.
        The text comes from speech recognition, so it may contain small mistakes.
        Reply with ONLY one JSON object and nothing else:
        {"action": "call" | "sms" | "unknown", "name": "...", "name_en": "...", "message": "..."}
        - action: "call" to phone someone, "sms" to text someone, otherwise "unknown".
        - name: the contact name exactly as spoken, in Bangla, without the suffix কে.
        - name_en: the same name transliterated into English letters.
        - message: only for "sms" — the text to send, in the language it was spoken,
          written the way the user would send it (e.g. "আমি দেরি করব").
        Use empty strings for fields that do not apply.
        Examples:
        Input: আম্মুকে ফোন করো
        Output: {"action":"call","name":"আম্মু","name_en":"Ammu","message":""}
        Input: রহিমকে বলে দাও আমি আধা ঘণ্টা পরে আসছি
        Output: {"action":"sms","name":"রহিম","name_en":"Rahim","message":"আমি আধা ঘণ্টা পরে আসছি"}
    """.trimIndent()

    /** ফেরত দেয় Command; বুঝতে না পারলে type = UNKNOWN। নেটওয়ার্ক/API ভুল হলে IOException। */
    suspend fun parse(apiKey: String, spoken: String): Command = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 300)
            .put("system", SYSTEM_PROMPT)
            .put(
                "messages",
                JSONArray().put(JSONObject().put("role", "user").put("content", spoken))
            )

        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 25_000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("anthropic-version", "2023-06-01")
        }

        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw IOException("HTTP $code ${err.take(200)}")
            }

            val response = conn.inputStream.bufferedReader().use { it.readText() }
            val text = JSONObject(response)
                .getJSONArray("content")
                .getJSONObject(0)
                .getString("text")

            toCommand(text)
        } finally {
            conn.disconnect()
        }
    }

    private fun toCommand(modelText: String): Command {
        val start = modelText.indexOf('{')
        val end = modelText.lastIndexOf('}')
        if (start < 0 || end <= start) return Command(ActionType.UNKNOWN)

        val json = try {
            JSONObject(modelText.substring(start, end + 1))
        } catch (e: Exception) {
            return Command(ActionType.UNKNOWN)
        }

        val type = when (json.optString("action").lowercase()) {
            "call" -> ActionType.CALL
            "sms" -> ActionType.SMS
            else -> ActionType.UNKNOWN
        }
        return Command(
            type = type,
            name = json.optString("name").trim(),
            nameEn = json.optString("name_en").trim(),
            message = json.optString("message").trim()
        )
    }
}
