package com.example.bnassistant

import android.content.Context
import android.content.Intent

data class AppMatch(val label: String, val intent: Intent)

object AppFinder {

    /** বাংলা নাম → ইংরেজি নাম/প্যাকেজের অংশ */
    private val aliases: List<Pair<String, String>> = listOf(
        "হোয়াটসঅ্যাপ" to "whatsapp", "হোয়াটস অ্যাপ" to "whatsapp", "হোয়াটসএপ" to "whatsapp",
        "হোয়াটসআপ" to "whatsapp", "হোয়াটস আপ" to "whatsapp",
        "ফেসবুক" to "facebook", "মেসেঞ্জার" to "messenger", "ইউটিউব" to "youtube",
        "ক্রোম" to "chrome", "গুগল ম্যাপ" to "maps", "ম্যাপস" to "maps", "ম্যাপ" to "maps",
        "জিমেইল" to "gmail", "ক্যামেরা" to "camera", "গ্যালারি" to "gallery", "ফটোস" to "photos",
        "ফটো" to "photos", "সেটিংস" to "settings", "সেটিং" to "settings",
        "প্লে স্টোর" to "play store", "প্লেস্টোর" to "play store", "টেলিগ্রাম" to "telegram",
        "ইনস্টাগ্রাম" to "instagram", "ইন্সটাগ্রাম" to "instagram", "ইমো" to "imo",
        "টিকটক" to "tiktok", "ক্যালকুলেটর" to "calculator", "ক্যালেন্ডার" to "calendar",
        "ঘড়ি" to "clock", "ক্লক" to "clock", "মেসেজিং" to "messages", "মেসেজ" to "messages",
        "ডায়ালার" to "phone", "ফোন" to "phone", "কন্টাক্টস" to "contacts", "কন্টাক্ট" to "contacts",
        "ফাইল ম্যানেজার" to "files", "ফাইলস" to "files", "ফাইল" to "files",
        "নোটস" to "notes", "নোট" to "notes", "স্পটিফাই" to "spotify", "ভাইবার" to "viber",
        "স্ন্যাপচ্যাট" to "snapchat", "টুইটার" to "twitter", "বিকাশ" to "bkash", "নগদ" to "nagad",
        "গুগল" to "google"
    ).sortedByDescending { it.first.length }

    fun find(ctx: Context, vararg names: String): AppMatch? {
        val terms = ArrayList<String>()
        for (n in names) {
            val t = TextUtil.normalize(n)
            if (t.isEmpty()) continue
            terms.add(t)
            for ((bn, en) in aliases) {
                if (t.contains(bn)) {
                    terms.add(en)
                    break
                }
            }
        }
        if (terms.isEmpty()) return null

        val pm = ctx.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        var best: AppMatch? = null
        var bestScore = Int.MAX_VALUE

        for (ri in pm.queryIntentActivities(query, 0)) {
            val pkg = ri.activityInfo.packageName
            val label = ri.loadLabel(pm).toString()
            val l = label.lowercase()
            val p = pkg.lowercase()

            val score = terms.minOf { t ->
                when {
                    l == t -> 0
                    l.startsWith(t) -> 1
                    l.contains(t) -> 2
                    p.contains(t) -> 3
                    else -> Int.MAX_VALUE
                }
            }
            if (score < bestScore) {
                val launch = pm.getLaunchIntentForPackage(pkg) ?: continue
                best = AppMatch(label, launch)
                bestScore = score
            }
        }
        return best
    }
}
