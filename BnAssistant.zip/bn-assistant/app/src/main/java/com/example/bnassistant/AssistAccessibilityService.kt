package com.example.bnassistant

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * স্ক্রিনে ট্যাপ, লেখা, হোম/ব্যাক ইত্যাদির জন্য।
 * সেটিংস → অ্যাক্সেসিবিলিটি থেকে একবার চালু করতে হয়।
 */
class AssistAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistAccessibilityService? = null

        fun isEnabled(): Boolean = instance != null

        /** হোয়াটসঅ্যাপের চ্যাট খোলার পর Send বাটনে ট্যাপ করে। */
        fun sendWhatsApp(pkg: String) {
            instance?.startSendLoop(pkg)
        }

        fun global(arg: String): Boolean {
            val s = instance ?: return false
            val action = when (arg) {
                "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                "back" -> AccessibilityService.GLOBAL_ACTION_BACK
                "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
                "lock" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN else return false
                "screenshot" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT else return false
                else -> return false
            }
            return s.performGlobalAction(action)
        }

        /** স্ক্রিনে এই লেখাওয়ালা বাটন/আইটেমে ট্যাপ করে। */
        fun clickText(text: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            val nodes = root.findAccessibilityNodeInfosByText(text)
            for (n in nodes) {
                var cur: AccessibilityNodeInfo? = n
                while (cur != null) {
                    if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    cur = cur.parent
                }
            }
            return false
        }

        /** যে ঘরে কার্সর আছে সেখানে লেখা যোগ করে। */
        fun typeText(text: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
            val existing = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
            val args = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    existing + text
                )
            }
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var sendGen = 0

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
    }

    private fun startSendLoop(pkg: String) {
        val gen = ++sendGen
        var tries = 0
        val r = object : Runnable {
            override fun run() {
                if (gen != sendGen) return
                tries++
                if (trySend(pkg)) {
                    toast("হোয়াটসঅ্যাপে পাঠানো হয়েছে")
                    return
                }
                if (tries < 20) {
                    mainHandler.postDelayed(this, 600)
                } else {
                    toast("Send বাটন পাইনি, নিজে চাপুন")
                }
            }
        }
        mainHandler.postDelayed(r, 1200)
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        while (cur != null) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
        }
        return false
    }

    private fun trySend(pkg: String): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != pkg) return false
        val nodes = ArrayList<AccessibilityNodeInfo>()
        nodes.addAll(root.findAccessibilityNodeInfosByViewId("$pkg:id/send"))
        if (nodes.isEmpty()) {
            for (d in listOf("Send", "পাঠান", "পাঠাও")) nodes.addAll(root.findAccessibilityNodeInfosByText(d))
        }
        for (n in nodes) {
            if (clickNodeOrParent(n)) return true
        }
        return false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}
}
