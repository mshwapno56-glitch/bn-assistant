package com.example.bnassistant

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * স্ক্রিনে ট্যাপ, লেখা, হোম/ব্যাক ইত্যাদির জন্য।
 * সেটিংস → অ্যাক্সেসিবিলিটি থেকে একবার চালু করতে হয়।
 */
class AssistAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistAccessibilityService? = null

        fun isEnabled(): Boolean = instance != null

        fun global(arg: String): Boolean {
            val s = instance ?: return false
            val action = when (arg) {
                "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                "back" -> AccessibilityService.GLOBAL_ACTION_BACK
                "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
                "lock" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN else return false
                "screenshot" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT else return false
                else -> return false
            }
            return s.performGlobalAction(action)
        }

        /** স্ক্রিনে এই লেখাওয়ালা বাটন/আইটেমে ট্যাপ করে। */
        fun clickText(text: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            val nodes = root.findAccessibilityNodeInfosByText(text)
            for (n in nodes) {
                var cur: AccessibilityNodeInfo? = n
                while (cur != null) {
                    if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    cur = cur.parent
                }
            }
            return false
        }

        /** যে ঘরে কার্সর আছে সেখানে লেখা যোগ করে। */
        fun typeText(text: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
            val existing = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
            val args = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    existing + text
                )
            }
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}
}
