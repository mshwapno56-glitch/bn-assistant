package com.example.bnassistant

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("bn_assistant", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("api_key", "").orEmpty().trim()
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("api_key", v.trim()).apply()

    fun confirm(c: Context): Boolean = sp(c).getBoolean("confirm", true)
    fun setConfirm(c: Context, v: Boolean) = sp(c).edit().putBoolean("confirm", v).apply()

    fun wakeWord(c: Context): String =
        sp(c).getString("wake_word", "").orEmpty().trim().ifEmpty { "বন্ধু" }

    fun setWakeWord(c: Context, v: String) = sp(c).edit().putString("wake_word", v.trim()).apply()
}
