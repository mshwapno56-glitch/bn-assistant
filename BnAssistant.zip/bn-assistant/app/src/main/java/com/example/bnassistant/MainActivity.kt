package com.example.bnassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var heardText: TextView
    private lateinit var logText: TextView
    private lateinit var listenButton: Button
    private lateinit var confirmCheck: CheckBox
    private lateinit var apiKeyInput: EditText
    private lateinit var saveButton: Button

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private val logLines = ArrayDeque<String>()

    private val prefs by lazy { getSharedPreferences("bn_assistant", MODE_PRIVATE) }
    private val apiKey: String get() = prefs.getString("api_key", "").orEmpty().trim()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.RECORD_AUDIO] == false) {
                log("মাইক্রোফোনের পারমিশন ছাড়া শোনা যাবে না।")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        heardText = findViewById(R.id.heardText)
        logText = findViewById(R.id.logText)
        listenButton = findViewById(R.id.listenButton)
        confirmCheck = findViewById(R.id.confirmCheck)
        apiKeyInput = findViewById(R.id.apiKeyInput)
        saveButton = findViewById(R.id.saveButton)

        confirmCheck.isChecked = prefs.getBoolean("confirm", true)
        apiKeyInput.setText(apiKey)

        confirmCheck.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("confirm", checked).apply()
        }
        saveButton.setOnClickListener {
            prefs.edit().putString("api_key", apiKeyInput.text.toString().trim()).apply()
            Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show()
        }
        listenButton.setOnClickListener { toggleListening() }

        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS
            )
        )

        setupRecognizer()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- শোনা

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.text = "এই ফোনে স্পিচ রিকগনিশন সার্ভিস নেই (Google অ্যাপ লাগবে)।"
            listenButton.isEnabled = false
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
    }

    private fun toggleListening() {
        val r = recognizer ?: return
        if (listening) {
            r.stopListening()
            return
        }
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        heardText.text = ""
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        r.startListening(intent)
    }

    private fun setListening(value: Boolean) {
        listening = value
        listenButton.text = getString(if (value) R.string.btn_listening else R.string.btn_listen)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = setListening(true)
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!partial.isNullOrBlank()) heardText.text = "\"$partial\""
        }

        override fun onResults(results: Bundle?) {
            setListening(false)
            val alternatives = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.filter { it.isNotBlank() }
                .orEmpty()
            if (alternatives.isEmpty()) {
                log("কিছু শুনতে পাইনি, আবার বলুন।")
            } else {
                handleSpoken(alternatives)
            }
        }

        override fun onError(error: Int) {
            setListening(false)
            log(
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কিছু শুনতে পাইনি, আবার বলুন।"
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "ইন্টারনেটে সমস্যা।"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "মাইক্রোফোনের পারমিশন নেই।"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "একটু পরে আবার চেষ্টা করুন।"
                    12, 13 -> "বাংলা ভাষা এই ফোনে সাপোর্ট করছে না। Google অ্যাপ আপডেট করুন বা ভাষা প্যাক নামান।"
                    else -> "শোনার সময় ত্রুটি (কোড $error)।"
                }
            )
        }
    }

    // ---------------------------------------------------------------- বোঝা ও করা

    private fun handleSpoken(alternatives: List<String>) {
        val spoken = alternatives.first()
        heardText.text = "\"$spoken\""

        if (!granted(Manifest.permission.READ_CONTACTS)) {
            log("কন্টাক্ট পড়ার পারমিশন দিন।")
            permissionLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS))
            return
        }

        lifecycleScope.launch {
            // ১) আগে কীওয়ার্ড — যেকোনো বিকল্প থেকে যেটা বোঝা যায়
            var cmd: Command? = alternatives
                .asSequence()
                .map { CommandParser.parse(it) }
                .firstOrNull { it.type != ActionType.UNKNOWN }
            var viaClaude = false

            // ২) না বুঝলে Claude
            if (cmd == null) {
                cmd = askClaude(spoken) ?: return@launch
                viaClaude = true
            }

            var matches = findContacts(cmd)

            // ৩) কীওয়ার্ডে নাম মেলেনি — Claude নামটা ঠিক করে দিতে পারে
            if (matches.isEmpty() && !viaClaude && apiKey.isNotEmpty()) {
                log("কন্টাক্টে পাইনি, Claude-এর সাহায্য নিচ্ছি…")
                val retry = askClaude(spoken)
                if (retry != null) {
                    cmd = retry
                    matches = findContacts(retry)
                }
            }

            if (matches.isEmpty()) {
                log("কন্টাক্টে \"${cmd.name}\" নামে কাউকে পাইনি।")
                return@launch
            }
            if (cmd.type == ActionType.SMS && cmd.message.isBlank()) {
                log("মেসেজে কী লিখব বুঝতে পারিনি। যেমন বলুন: \"আম্মুকে মেসেজ পাঠাও যে আমি আসছি\"")
                return@launch
            }

            val finalCmd: Command = cmd
            if (matches.size == 1) {
                confirmAndRun(finalCmd, matches.first())
            } else {
                chooseContact(finalCmd, matches.take(8))
            }
        }
    }

    private suspend fun askClaude(spoken: String): Command? {
        if (apiKey.isEmpty()) {
            log("কমান্ড বুঝতে পারিনি। নিচে Claude API key দিলে আরও ভালো বুঝবে।")
            return null
        }
        log("Claude-কে জিজ্ঞেস করছি…")
        return try {
            val c = ClaudeClient.parse(apiKey, spoken)
            if (c.type == ActionType.UNKNOWN || c.name.isEmpty()) {
                log("কমান্ড বুঝতে পারিনি। \"রহিমকে ফোন দাও\" ধরনের করে বলুন।")
                null
            } else {
                c
            }
        } catch (e: Exception) {
            log("Claude ত্রুটি: ${e.message}")
            null
        }
    }

    private suspend fun findContacts(cmd: Command): List<ContactMatch> =
        withContext(Dispatchers.IO) {
            ContactFinder.find(this@MainActivity, cmd.name, cmd.nameEn)
        }

    private fun chooseContact(cmd: Command, matches: List<ContactMatch>) {
        AlertDialog.Builder(this)
            .setTitle("কোনজন?")
            .setItems(matches.map { "${it.name}\n${it.number}" }.toTypedArray()) { _, i ->
                confirmAndRun(cmd, matches[i])
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun confirmAndRun(cmd: Command, match: ContactMatch) {
        if (!confirmCheck.isChecked) {
            run(cmd, match)
            return
        }
        val text = when (cmd.type) {
            ActionType.CALL -> "${match.name} (${match.number}) কে ফোন করবেন?"
            ActionType.SMS -> "${match.name} (${match.number}) কে পাঠাবেন:\n\n${cmd.message}"
            ActionType.UNKNOWN -> return
        }
        AlertDialog.Builder(this)
            .setMessage(text)
            .setPositiveButton("হ্যাঁ") { _, _ -> run(cmd, match) }
            .setNegativeButton("না") { _, _ -> log("বাতিল করা হয়েছে।") }
            .show()
    }

    private fun run(cmd: Command, match: ContactMatch) {
        try {
            when (cmd.type) {
                ActionType.CALL -> {
                    if (!granted(Manifest.permission.CALL_PHONE)) {
                        permissionLauncher.launch(arrayOf(Manifest.permission.CALL_PHONE))
                        log("কল করার পারমিশন দিয়ে আবার বলুন।")
                        return
                    }
                    ActionRunner.call(this, match.number)
                    log("${match.name}-কে কল করা হচ্ছে…")
                }
                ActionType.SMS -> {
                    if (!granted(Manifest.permission.SEND_SMS)) {
                        permissionLauncher.launch(arrayOf(Manifest.permission.SEND_SMS))
                        log("SMS পাঠানোর পারমিশন দিয়ে আবার বলুন।")
                        return
                    }
                    ActionRunner.sendSms(this, match.number, cmd.message)
                    log("${match.name}-কে মেসেজ পাঠানো হয়েছে।")
                }
                ActionType.UNKNOWN -> {}
            }
        } catch (e: Exception) {
            log("কাজটা করা যায়নি: ${e.message}")
        }
    }

    // ---------------------------------------------------------------- সাহায্যকারী

    private fun granted(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun log(message: String) {
        logLines.addLast(message)
        while (logLines.size > 6) logLines.removeFirst()
        logText.text = logLines.joinToString("\n")
    }
}
