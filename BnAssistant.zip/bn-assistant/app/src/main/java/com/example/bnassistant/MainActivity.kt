package com.example.bnassistant

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var diagText: TextView
    private lateinit var heardText: TextView
    private lateinit var logText: TextView
    private lateinit var permStatus: TextView
    private lateinit var listenButton: Button
    private lateinit var confirmCheck: CheckBox
    private lateinit var wakeInput: EditText
    private lateinit var apiKeyInput: EditText
    private lateinit var serviceSwitch: SwitchCompat

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var updatingSwitch = false
    private val logLines = ArrayDeque<String>()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.RECORD_AUDIO] == false) {
                log("মাইক্রোফোনের পারমিশন ছাড়া শোনা যাবে না।")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        diagText = findViewById(R.id.diagText)
        heardText = findViewById(R.id.heardText)
        logText = findViewById(R.id.logText)
        permStatus = findViewById(R.id.permStatus)
        listenButton = findViewById(R.id.listenButton)
        confirmCheck = findViewById(R.id.confirmCheck)
        wakeInput = findViewById(R.id.wakeInput)
        apiKeyInput = findViewById(R.id.apiKeyInput)
        serviceSwitch = findViewById(R.id.serviceSwitch)

        confirmCheck.isChecked = Prefs.confirm(this)
        wakeInput.setText(Prefs.wakeWord(this))
        apiKeyInput.setText(Prefs.apiKey(this))

        confirmCheck.setOnCheckedChangeListener { _, checked -> Prefs.setConfirm(this, checked) }

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            Prefs.setApiKey(this, apiKeyInput.text.toString())
            Prefs.setWakeWord(this, wakeInput.text.toString())
            Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show()
            if (AssistantService.running) {
                Toast.makeText(this, "জাগানোর শব্দ বদলাতে সুইচ বন্ধ করে আবার চালু করুন", Toast.LENGTH_LONG).show()
            }
        }

        listenButton.setOnClickListener { toggleListening() }

        serviceSwitch.setOnCheckedChangeListener { _, checked ->
            if (updatingSwitch) return@setOnCheckedChangeListener
            if (checked) startBackground() else stopBackground()
        }

        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            openSettings(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")),
                Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            )
        }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            openSettings(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            openSettings(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), null)
        }
        findViewById<Button>(R.id.btnAppSettings).setOnClickListener {
            openSettings(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")),
                null
            )
        }

        requestAllPermissions()
        setupRecognizer()
        checkBengaliSupport()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- পারমিশন ও সেটিংস

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun requestAllPermissions() {
        val list = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = list.filter { !granted(it) }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    private fun openSettings(primary: Intent, fallback: Intent?) {
        try {
            startActivity(primary)
        } catch (e: Exception) {
            try {
                if (fallback != null) startActivity(fallback)
            } catch (e2: Exception) {
                log("সেটিংস খোলা গেল না।")
            }
        }
    }

    private fun tick(b: Boolean) = if (b) "✓" else "✗"

    private fun refreshStatus() {
        val pm = getSystemService(PowerManager::class.java)
        val battery = try {
            pm.isIgnoringBatteryOptimizations(packageName)
        } catch (e: Exception) {
            false
        }
        val overlay = Settings.canDrawOverlays(this)
        permStatus.text = "অবস্থা:  ব্যাটারি ${tick(battery)}   ওভারলে ${tick(overlay)}   " +
            "অ্যাক্সেসিবিলিটি ${tick(AssistAccessibilityService.isEnabled())}"

        updatingSwitch = true
        serviceSwitch.isChecked = AssistantService.running
        updatingSwitch = false
        applyServiceUi()
    }

    private fun applyServiceUi() {
        val on = AssistantService.running || serviceSwitch.isChecked
        listenButton.isEnabled = !on
        listenButton.text = getString(
            if (on) R.string.btn_listen_disabled else if (listening) R.string.btn_listening else R.string.btn_listen
        )
    }

    // ---------------------------------------------------------------- ব্যাকগ্রাউন্ড সার্ভিস

    private fun startBackground() {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            requestAllPermissions()
            updatingSwitch = true
            serviceSwitch.isChecked = false
            updatingSwitch = false
            log("আগে মাইক্রোফোনের পারমিশন দিন, তারপর সুইচ চালু করুন।")
            return
        }
        if (listening) recognizer?.cancel()
        listening = false
        Prefs.setWakeWord(this, wakeInput.text.toString())
        try {
            AssistantService.start(this)
            log("ব্যাকগ্রাউন্ডে শুনছি। \"${Prefs.wakeWord(this)}\" বলে শুরু করুন।")
        } catch (e: Exception) {
            log("সার্ভিস চালু করা যায়নি: ${e.message}")
            updatingSwitch = true
            serviceSwitch.isChecked = false
            updatingSwitch = false
        }
        applyServiceUi()
    }

    private fun stopBackground() {
        AssistantService.stop(this)
        log("ব্যাকগ্রাউন্ড বন্ধ করা হয়েছে।")
        listenButton.isEnabled = true
        listenButton.text = getString(R.string.btn_listen)
    }

    // ---------------------------------------------------------------- ডায়াগনস্টিক

    private fun checkBengaliSupport() {
        try {
            val intent = RecognizerIntent.getVoiceDetailsIntent(this)
            if (intent == null) {
                diagText.text = "বাংলা সাপোর্ট: স্পিচ সার্ভিস পাওয়া যায়নি"
                return
            }
            sendOrderedBroadcast(intent, null, object : BroadcastReceiver() {
                override fun onReceive(c: Context?, i: Intent?) {
                    val langs = getResultExtras(true)
                        ?.getStringArrayList(RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES)
                    diagText.text = when {
                        langs == null -> "বাংলা সাপোর্ট: জানা যায়নি"
                        langs.any { it.startsWith("bn", ignoreCase = true) } -> "বাংলা সাপোর্ট: আছে ✓"
                        else -> "বাংলা সাপোর্ট: নেই ✗ (Google অ্যাপে বাংলা ভয়েস যোগ করুন)"
                    }
                }
            }, null, RESULT_OK, null, null)
        } catch (e: Exception) {
            diagText.text = "বাংলা সাপোর্ট: যাচাই করা যায়নি"
        }
    }

    // ---------------------------------------------------------------- হাতে বাটন চেপে শোনা

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.text = "এই ফোনে স্পিচ রিকগনিশন সার্ভিস নেই (Google অ্যাপ লাগবে)।"
            listenButton.isEnabled = false
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
    }

    private fun toggleListening() {
        val r = recognizer ?: return
        if (listening) {
            r.stopListening()
            return
        }
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        heardText.text = ""
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        r.startListening(intent)
    }

    private fun setListening(value: Boolean) {
        listening = value
        applyServiceUi()
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = setListening(true)
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!partial.isNullOrBlank()) heardText.text = "\"$partial\""
        }

        override fun onResults(results: Bundle?) {
            setListening(false)
            val alternatives = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.filter { it.isNotBlank() }
                .orEmpty()
            if (alternatives.isEmpty()) {
                log("কিছু শুনতে পাইনি, আবার বলুন।")
            } else {
                handleSpoken(alternatives)
            }
        }

        override fun onError(error: Int) {
            setListening(false)
            val text = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH -> "কিছু বুঝতে পারেনি, আবার বলুন"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কোনো কথা শোনেনি, বাটন চেপে সাথে সাথে বলুন"
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "ইন্টারনেটে সমস্যা"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "মাইক্রোফোনের পারমিশন নেই"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "একটু পরে আবার চেষ্টা করুন"
                SpeechRecognizer.ERROR_AUDIO -> "মাইক্রোফোন ব্যবহার করা যাচ্ছে না"
                SpeechRecognizer.ERROR_SERVER -> "স্পিচ সার্ভারে সমস্যা"
                12, 13 -> "বাংলা ভাষা এই ফোনে সাপোর্ট করছে না। Google অ্যাপ আপডেট করুন বা বাংলা ভয়েস ডেটা নামান"
                else -> "শোনার সময় ত্রুটি"
            }
            log("$text (কোড $error)")
        }
    }

    // ---------------------------------------------------------------- বোঝা ও করা

    private fun handleSpoken(alternatives: List<String>) {
        heardText.text = "\"${alternatives.first()}\""
        lifecycleScope.launch {
            val r = Brain.resolve(this@MainActivity, alternatives, Prefs.apiKey(this@MainActivity)) { log(it) }
            if (r == null) {
                log("কমান্ড বুঝতে পারিনি। \"রহিমকে ফোন দাও\" ধরনের করে বলুন।")
                return@launch
            }
            val cmd = r.cmd
            if (!cmd.needsContact) {
                log(Executor.run(this@MainActivity, cmd, null))
                return@launch
            }
            if (r.matches.isEmpty()) {
                log("কন্টাক্টে \"${cmd.name}\" নামে কাউকে পাইনি।")
                return@launch
            }
            if (cmd.type == ActionType.SMS && cmd.message.isBlank()) {
                log("মেসেজে কী লিখব বুঝতে পারিনি। যেমন বলুন: \"আম্মুকে মেসেজ পাঠাও যে আমি আসছি\"")
                return@launch
            }
            if (r.matches.size == 1) {
                confirmAndRun(cmd, r.matches.first())
            } else {
                chooseContact(cmd, r.matches.take(8))
            }
        }
    }

    private fun chooseContact(cmd: Command, matches: List<ContactMatch>) {
        AlertDialog.Builder(this)
            .setTitle("কোনজন?")
            .setItems(matches.map { "${it.name}\n${it.number}" }.toTypedArray()) { _, i ->
                confirmAndRun(cmd, matches[i])
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun confirmAndRun(cmd: Command, match: ContactMatch) {
        if (!confirmCheck.isChecked) {
            log(Executor.run(this, cmd, match))
            return
        }
        val text = if (cmd.type == ActionType.CALL) {
            "${match.name} (${match.number}) কে ফোন করবেন?"
        } else {
            "${match.name} (${match.number}) কে পাঠাবেন:\n\n${cmd.message}"
        }
        AlertDialog.Builder(this)
            .setMessage(text)
            .setPositiveButton("হ্যাঁ") { _, _ -> log(Executor.run(this, cmd, match)) }
            .setNegativeButton("না") { _, _ -> log("বাতিল করা হয়েছে।") }
            .show()
    }

    private fun log(message: String) {
        logLines.addLast(message)
        while (logLines.size > 6) logLines.removeFirst()
        logText.text = logLines.joinToString("\n")
    }
}
