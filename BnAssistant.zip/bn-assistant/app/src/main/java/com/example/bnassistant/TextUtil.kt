package com.example.bnassistant

object TextUtil {

    /** ছোট হাতের অক্ষর, ZWJ/ZWNJ বাদ, বাড়তি স্পেস বাদ। */
    fun normalize(s: String): String =
        s.lowercase()
            .replace("‌", "")
            .replace("‍", "")
            .replace(Regex("\\s+"), " ")
            .trim()

    /** বাংলা অঙ্ক (০-৯) কে ইংরেজি অঙ্কে বদলায়। */
    fun bnDigits(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            if (ch in '০'..'৯') sb.append('0' + (ch - '০')) else sb.append(ch)
        }
        return sb.toString()
    }
}
