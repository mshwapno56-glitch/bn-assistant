package com.example.bnassistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * ব্যাকগ্রাউন্ডে সবসময় বাংলা শোনে। জাগানোর শব্দ ("বন্ধু") শুনলে কমান্ড ধরে।
 *   WAKE    : জাগানোর শব্দের অপেক্ষা
 *   COMMAND : শব্দ শুনেছে, কমান্ডের অপেক্ষা (৮ সেকেন্ড)
 *   CONFIRM : কল/মেসেজের আগে "হ্যাঁ/না"-র অপেক্ষা (১০ সেকেন্ড)
 *   RINGING : কল আসছে — "ধরো" / "কেটে দাও" শোনে (জাগানোর শব্দ ছাড়াই)
 *   PAUSED  : কলে আছেন, শোনা বন্ধ
 */
class AssistantService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.bnassistant.STOP"
        private const val CHANNEL_ID = "assistant"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, AssistantService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AssistantService::class.java))
        }
    }

    private enum class Mode { WAKE, COMMAND, CONFIRM, RINGING, PAUSED }

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var busy = false
    private var destroyed = false
    private var mode = Mode.WAKE
    private var deadline = 0L
    private var errorStreak = 0
    private var pending: Pair<Command, ContactMatch>? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var tone: ToneGenerator? = null
    private var phoneReceiver: BroadcastReceiver? = null
    private var ringNumber: String? = null
    private var ringAnnounced = false
    private val announceRunnable = Runnable { announceCall() }

    private val restartRunnable = Runnable { startListening() }

    // ------------------------------------------------------------ জীবনচক্র

    override fun onCreate() {
        super.onCreate()
        running = true
        createChannel()
        try {
            val n = buildNotification(idleText())
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return
        }

        try {
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bnassistant:listen").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Exception) {
        }
        try {
            tone = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
        } catch (e: Exception) {
        }

        initTts()
        registerPhoneReceiver()
        scheduleRestart(300)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        destroyed = true
        running = false
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
        }
        recognizer = null
        try {
            tts?.shutdown()
        } catch (e: Exception) {
        }
        phoneReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (e: Exception) {
            }
        }
        try {
            wakeLock?.release()
        } catch (e: Exception) {
        }
        try {
            tone?.release()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    // ------------------------------------------------------------ নোটিফিকেশন

    private fun idleText() = "শুনছি… \"${Prefs.wakeWord(this)}\" বলে শুরু করুন"

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "ভয়েস অ্যাসিস্ট্যান্ট", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("বাংলা অ্যাসিস্ট্যান্ট")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .addAction(0, "বন্ধ করুন", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    private fun setStatus(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ কথা বলা (TTS) ও বিপ

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("bn", "BD"))
                ttsReady = r != null && r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        handler.post { speakingDone() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        handler.post { speakingDone() }
                    }
                })
            }
        }
    }

    private fun speakingDone() {
        if (!speaking) return
        speaking = false
        scheduleRestart(300)
    }

    private fun beep() {
        try {
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        } catch (e: Exception) {
        }
    }

    /** বার্তা নোটিফিকেশনে দেখায়, বাংলা TTS থাকলে মুখেও বলে। শেষ হলে আবার শোনা শুরু। */
    private fun say(text: String) {
        setStatus(text)
        if (!ttsReady) {
            beep()
            scheduleRestart(500)
            return
        }
        speaking = true
        handler.removeCallbacks(restartRunnable)
        try {
            recognizer?.cancel()
        } catch (e: Exception) {
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
        handler.postDelayed({
            if (speaking) speakingDone()
        }, 8000)
    }

    // ------------------------------------------------------------ শোনা

    private fun hasPerm(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun scheduleRestart(delayMs: Long) {
        if (destroyed) return
        handler.removeCallbacks(restartRunnable)
        handler.postDelayed(restartRunnable, delayMs)
    }

    private fun rebuildRecognizer() {
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
        }
        recognizer = null
    }

    private fun startListening() {
        if (destroyed || speaking || busy || mode == Mode.PAUSED) return
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) {
            setStatus("মাইক্রোফোনের পারমিশন নেই")
            stopSelf()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("এই ফোনে স্পিচ রিকগনিশন সার্ভিস নেই (Google অ্যাপ লাগবে)")
            stopSelf()
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(listener)
            }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            rebuildRecognizer()
            scheduleRestart(1500)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onResults(results: Bundle?) {
            errorStreak = 0
            val alts = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.filter { it.isNotBlank() }
                .orEmpty()
            if (alts.isEmpty()) {
                expireIfNeeded()
                scheduleRestart(200)
            } else {
                onSpeech(alts)
            }
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    errorStreak = 0
                    expireIfNeeded()
                    scheduleRestart(200)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    rebuildRecognizer()
                    scheduleRestart(1000)
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    setStatus("মাইক্রোফোনের পারমিশন নেই")
                    stopSelf()
                }
                12, 13 -> {
                    setStatus("বাংলা ভাষা এই ফোনে সাপোর্ট করছে না (কোড $error)। Google অ্যাপ আপডেট করে বাংলা ভয়েস ডেটা নামান।")
                    stopSelf()
                }
                else -> {
                    errorStreak++
                    if (errorStreak >= 3) rebuildRecognizer()
                    scheduleRestart(minOf(5000L, 1000L * errorStreak))
                }
            }
        }
    }

    private fun expireIfNeeded() {
        if ((mode == Mode.COMMAND || mode == Mode.CONFIRM) && System.currentTimeMillis() > deadline) {
            mode = Mode.WAKE
            pending = null
            setStatus(idleText())
        }
    }

    // ------------------------------------------------------------ কথা বোঝা

    private fun onSpeech(alts: List<String>) {
        when (mode) {
            Mode.WAKE -> {
                val wake = TextUtil.normalize(Prefs.wakeWord(this))
                val rests = alts.mapNotNull { a ->
                    val n = TextUtil.normalize(a)
                    val i = n.indexOf(wake)
                    if (i >= 0) n.substring(i + wake.length).trim(' ', ',', '।', '.') else null
                }
                if (rests.isEmpty()) {
                    scheduleRestart(100)
                    return
                }
                val nonBlank = rests.filter { it.isNotBlank() }
                if (nonBlank.isNotEmpty()) {
                    handleCommand(nonBlank)
                } else {
                    mode = Mode.COMMAND
                    deadline = System.currentTimeMillis() + 8000
                    beep()
                    setStatus("বলুন…")
                    scheduleRestart(100)
                }
            }
            Mode.COMMAND -> handleCommand(alts)
            Mode.CONFIRM -> handleConfirm(alts)
            Mode.RINGING -> handleRinging(alts)
            Mode.PAUSED -> {}
        }
    }

    private fun finishWith(msg: String) {
        mode = Mode.WAKE
        pending = null
        say(msg)
    }

    private fun handleCommand(alts: List<String>) {
        busy = true
        setStatus("বুঝছি…")
        scope.launch {
            try {
                val r = Brain.resolve(this@AssistantService, alts, Prefs.apiKey(this@AssistantService)) { setStatus(it) }
                if (r == null) {
                    finishWith("বুঝতে পারিনি")
                    return@launch
                }
                val cmd = r.cmd
                if (!cmd.needsContact) {
                    finishWith(Executor.run(this@AssistantService, cmd, null))
                    return@launch
                }
                if (r.matches.isEmpty()) {
                    finishWith("কন্টাক্টে ${cmd.name} নামে কাউকে পাইনি")
                    return@launch
                }
                if (cmd.isMessage && cmd.message.isBlank()) {
                    finishWith("মেসেজে কী লিখব বুঝিনি")
                    return@launch
                }
                val m = r.matches.first()
                if (Prefs.confirm(this@AssistantService)) {
                    pending = cmd to m
                    mode = Mode.CONFIRM
                    deadline = System.currentTimeMillis() + 10000
                    say(
                        when (cmd.type) {
                            ActionType.CALL -> "${m.name}-কে ফোন করব?"
                            ActionType.APP_MSG -> "${m.name}-কে হোয়াটসঅ্যাপে পাঠাব: ${cmd.message}?"
                            else -> "${m.name}-কে পাঠাব: ${cmd.message}?"
                        }
                    )
                } else {
                    finishWith(Executor.run(this@AssistantService, cmd, m))
                }
            } finally {
                busy = false
            }
        }
    }

    private val yesWords = setOf("হ্যাঁ", "হ্যা", "হাঁ", "হা", "ঠিক", "করো", "কর", "পাঠাও", "দাও", "ok", "okay", "yes", "হুম")
    private val noWords = setOf("না", "নাহ", "থাক", "বাদ", "বাতিল", "থামো", "cancel", "no", "নো")

    private fun handleConfirm(alts: List<String>) {
        val tokens = alts.flatMap { TextUtil.normalize(it).split(" ", ",", "।") }.toSet()
        val p = pending
        when {
            p == null -> finishWith("কিছু করার নেই")
            tokens.any { it in noWords } -> finishWith("ঠিক আছে, বাতিল")
            tokens.any { it in yesWords } -> finishWith(Executor.run(this, p.first, p.second))
            else -> {
                expireIfNeeded()
                scheduleRestart(100)
            }
        }
    }

    private val answerWords = setOf("হ্যাঁ", "হ্যা", "হাঁ", "ধরো", "ধরুন", "ধর", "রিসিভ", "তোলো", "তুলো", "ঠিক", "yes", "ok")
    private val rejectWords = setOf("না", "নাহ", "কেটে", "কাটো", "কাটুন", "রিজেক্ট", "বাদ", "থাক", "রাখো", "no")

    /** কল আসার সময় "ধরো/হ্যাঁ" বললে ধরে, "কেটে দাও/না" বললে কেটে দেয়। */
    private fun handleRinging(alts: List<String>) {
        val tokens = alts.flatMap { TextUtil.normalize(it).split(" ", ",", "।") }.toSet()
        val kw = Brain.keyword(alts)?.type
        val action = when {
            kw == ActionType.REJECT_CALL -> ActionType.REJECT_CALL
            kw == ActionType.ANSWER_CALL -> ActionType.ANSWER_CALL
            tokens.any { it in rejectWords } -> ActionType.REJECT_CALL
            tokens.any { it in answerWords } -> ActionType.ANSWER_CALL
            else -> null
        }
        if (action != null) {
            handler.removeCallbacks(announceRunnable)
            setStatus(Executor.run(this, Command(action), null))
        }
        scheduleRestart(200)
    }

    private fun lookupName(number: String): String? {
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) return null
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        return try {
            contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    /** কে ফোন করছে মুখে জানায়, তারপর আপনার কমান্ডের অপেক্ষা করে। */
    private fun announceCall() {
        if (mode != Mode.RINGING || ringAnnounced) return
        ringAnnounced = true
        val num = ringNumber
        scope.launch {
            val name = if (num.isNullOrBlank()) null else withContext(Dispatchers.IO) { lookupName(num) }
            val who = when {
                name != null -> name
                !num.isNullOrBlank() -> "অজানা নম্বর $num"
                else -> "কেউ"
            }
            if (mode == Mode.RINGING) say("$who কল করছেন। ধরব, না কেটে দেব?")
        }
    }

    // ------------------------------------------------------------ ফোন কলের অবস্থা

    private fun registerPhoneReceiver() {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                when (i?.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                    TelephonyManager.EXTRA_STATE_RINGING -> {
                        val num = i?.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                        if (mode != Mode.RINGING) {
                            mode = Mode.RINGING
                            pending = null
                            ringNumber = null
                            ringAnnounced = false
                            setStatus("কল আসছে…")
                            try {
                                recognizer?.cancel()
                            } catch (e: Exception) {
                            }
                            handler.postDelayed(announceRunnable, 900)
                        }
                        if (!num.isNullOrBlank()) {
                            ringNumber = num
                            if (!ringAnnounced) {
                                handler.removeCallbacks(announceRunnable)
                                handler.post(announceRunnable)
                            }
                        }
                    }
                    TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                        mode = Mode.PAUSED
                        handler.removeCallbacks(announceRunnable)
                        handler.removeCallbacks(restartRunnable)
                        try {
                            recognizer?.cancel()
                        } catch (e: Exception) {
                        }
                        setStatus("কলে আছেন — শোনা বিরতি")
                    }
                    TelephonyManager.EXTRA_STATE_IDLE -> {
                        handler.removeCallbacks(announceRunnable)
                        if (mode == Mode.PAUSED || mode == Mode.RINGING) {
                            mode = Mode.WAKE
                            setStatus(idleText())
                            scheduleRestart(800)
                        }
                    }
                }
            }
        }
        phoneReceiver = r
        try {
            ContextCompat.registerReceiver(
                this, r, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (e: Exception) {
            phoneReceiver = null
        }
    }
}
