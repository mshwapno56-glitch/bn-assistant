package com.example.bnassistant

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Phone

data class ContactMatch(val name: String, val number: String)

object ContactFinder {

    /** বাংলা বা ইংরেজি যেকোনো নাম দিয়ে কন্টাক্ট খোঁজে। সবচেয়ে মিলে যাওয়াগুলো আগে। */
    fun find(context: Context, vararg queries: String): List<ContactMatch> {
        val terms = queries.map { normalize(it) }.filter { it.isNotEmpty() }
        if (terms.isEmpty()) return emptyList()

        val scored = ArrayList<Triple<Int, String, ContactMatch>>()
        val seenNumbers = HashSet<String>()

        val projection = arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER)
        context.contentResolver.query(
            Phone.CONTENT_URI, projection, null, null, Phone.DISPLAY_NAME + " ASC"
        )?.use { c ->
            val nameIdx = c.getColumnIndexOrThrow(Phone.DISPLAY_NAME)
            val numIdx = c.getColumnIndexOrThrow(Phone.NUMBER)
            while (c.moveToNext()) {
                val name = c.getString(nameIdx) ?: continue
                val number = c.getString(numIdx) ?: continue
                val n = normalize(name)

                val score = terms.minOf { t ->
                    when {
                        n == t -> 0
                        n.startsWith(t) -> 1
                        n.contains(t) -> 2
                        else -> Int.MAX_VALUE
                    }
                }
                if (score == Int.MAX_VALUE) continue

                val digits = number.filter { it.isDigit() }
                if (!seenNumbers.add(digits)) continue
                scored.add(Triple(score, n, ContactMatch(name, number)))
            }
        }

        return scored
            .sortedWith(compareBy({ it.first }, { it.second }))
            .map { it.third }
    }

    private fun normalize(s: String): String =
        s.lowercase()
            .replace("‌", "")
            .replace("‍", "")
            .replace(Regex("\\s+"), " ")
            .trim()
}
