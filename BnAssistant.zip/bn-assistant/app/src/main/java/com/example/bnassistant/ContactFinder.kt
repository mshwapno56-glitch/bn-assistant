package com.example.bnassistant

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Phone

data class ContactMatch(val name: String, val number: String)

object ContactFinder {

    /**
     * বাংলা বা ইংরেজি যেকোনো নাম দিয়ে কন্টাক্ট খোঁজে।
     * ১) আগে হুবহু/শুরু/ভেতরের মিল (একই লিপিতে)। ২) কিছু না পেলে উচ্চারণ মিলিয়ে বাংলা↔ইংরেজি।
     */
    fun find(context: Context, vararg queries: String): List<ContactMatch> {
        val terms = queries.map { normalize(it) }.filter { it.isNotEmpty() }
        if (terms.isEmpty()) return emptyList()

        val skels = terms
            .filter { Phonetic.hasBengali(it) }
            .map { Phonetic.skeleton(it) }
            .filter { it.length >= 2 }
            .distinct()

        val direct = ArrayList<Triple<Int, String, ContactMatch>>()
        val fuzzy = ArrayList<Triple<Int, String, ContactMatch>>()
        val seenDirect = HashSet<String>()
        val seenFuzzy = HashSet<String>()

        val projection = arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER)
        context.contentResolver.query(
            Phone.CONTENT_URI, projection, null, null, Phone.DISPLAY_NAME + " ASC"
        )?.use { c ->
            val nameIdx = c.getColumnIndexOrThrow(Phone.DISPLAY_NAME)
            val numIdx = c.getColumnIndexOrThrow(Phone.NUMBER)
            while (c.moveToNext()) {
                val name = c.getString(nameIdx) ?: continue
                val number = c.getString(numIdx) ?: continue
                val n = normalize(name)
                val digits = number.filter { it.isDigit() }

                val score = terms.minOf { t ->
                    when {
                        n == t -> 0
                        n.startsWith(t) -> 1
                        n.contains(t) -> 2
                        else -> Int.MAX_VALUE
                    }
                }
                if (score != Int.MAX_VALUE) {
                    if (seenDirect.add(digits)) direct.add(Triple(score, n, ContactMatch(name, number)))
                    continue
                }

                if (skels.isNotEmpty()) {
                    val ns = Phonetic.skeleton(name)
                    val fs = skels.minOf { s ->
                        when {
                            ns == s -> 0
                            ns.startsWith(s) && s.length >= 3 -> 1
                            ns.contains(s) && s.length >= 3 -> 2
                            else -> Int.MAX_VALUE
                        }
                    }
                    if (fs != Int.MAX_VALUE && seenFuzzy.add(digits)) {
                        fuzzy.add(Triple(fs, n, ContactMatch(name, number)))
                    }
                }
            }
        }

        val chosen = if (direct.isNotEmpty()) direct else fuzzy
        return chosen
            .sortedWith(compareBy({ it.first }, { it.second }))
            .map { it.third }
    }

    private fun normalize(s: String): String =
        TextUtil.normalize(s)
}
