package com.example.bnassistant

/**
 * বাংলা ও ইংরেজি নামের "ব্যঞ্জনের কাঠামো" বের করে, যাতে "রহিম" আর "Rahim" একই কাঠামো ("rhm") পায়।
 * স্বরবর্ণ বাদ যায়, সমউচ্চারণের ব্যঞ্জন এক অক্ষরে নেমে আসে। অনুমান-ভিত্তিক, তাই শুধু শেষ ভরসা হিসেবে ব্যবহার হয়।
 */
object Phonetic {

    private val bn: Map<Char, Char> = mapOf(
        'ক' to 'k', 'খ' to 'k', 'গ' to 'g', 'ঘ' to 'g', 'ঙ' to 'n',
        'চ' to 'c', 'ছ' to 'c', 'জ' to 'j', 'ঝ' to 'j', 'ঞ' to 'n',
        'ট' to 't', 'ঠ' to 't', 'ড' to 'd', 'ঢ' to 'd', 'ণ' to 'n',
        'ত' to 't', 'থ' to 't', 'দ' to 'd', 'ধ' to 'd', 'ন' to 'n',
        'প' to 'p', 'ফ' to 'f', 'ব' to 'b', 'ভ' to 'b', 'ম' to 'm',
        'য' to 'j', 'র' to 'r', 'ল' to 'l', 'শ' to 's', 'ষ' to 's',
        'স' to 's', 'হ' to 'h'
    )

    fun hasBengali(s: String): Boolean = s.any { it in 'ঀ'..'৿' }

    fun skeleton(s: String): String {
        val l = s.lowercase()
        val sb = StringBuilder()
        var prevBn = ' '
        var i = 0
        while (i < l.length) {
            val c = l[i]
            val next = if (i + 1 < l.length) l[i + 1] else ' '
            val mapped = bn[c]
            when {
                mapped != null -> {
                    sb.append(mapped)
                    prevBn = c
                }
                c == '়' -> { // নুক্তা: ড়, ঢ়, য়
                    if (sb.isNotEmpty()) {
                        if (prevBn == 'ড' || prevBn == 'ঢ') sb.setCharAt(sb.length - 1, 'r')
                        else if (prevBn == 'য') sb.setLength(sb.length - 1)
                    }
                    prevBn = ' '
                }
                c == 'ড়' || c == 'ঢ়' -> sb.append('r')
                c == 'ৎ' -> sb.append('t')
                c in 'a'..'z' -> {
                    if (c !in "aeiouyw") {
                        val two = "$c$next"
                        when (two) {
                            "ch" -> { sb.append('c'); i++ }
                            "sh" -> { sb.append('s'); i++ }
                            "th" -> { sb.append('t'); i++ }
                            "dh" -> { sb.append('d'); i++ }
                            "kh" -> { sb.append('k'); i++ }
                            "gh" -> { sb.append('g'); i++ }
                            "ph" -> { sb.append('f'); i++ }
                            "bh" -> { sb.append('b'); i++ }
                            "jh" -> { sb.append('j'); i++ }
                            else -> sb.append(
                                when (c) {
                                    'q', 'x', 'c' -> 'k'
                                    'z' -> 'j'
                                    'v' -> 'b'
                                    else -> c
                                }
                            )
                        }
                    }
                }
            }
            i++
        }
        return sb.toString()
    }
}
