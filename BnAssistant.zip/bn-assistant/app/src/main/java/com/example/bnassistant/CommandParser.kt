package com.example.bnassistant

/**
 * কীওয়ার্ড দিয়ে বাংলা কমান্ড বোঝা — ফ্রি, ইন্টারনেট ছাড়াই চলে।
 * না বুঝলে ActionType.UNKNOWN ফেরত দেয়, তখন Claude API ব্যবহার হয়।
 *
 * বোঝে এমন বাক্য:
 *   "রহিমকে ফোন দাও" / "রহিমকে কল করো"
 *   "আম্মুকে মেসেজ পাঠাও যে আমি দেরি করব"
 */
object CommandParser {

    private val callVerbs = listOf(
        "ফোন দাও", "ফোন করো", "ফোন কর", "ফোন দিন", "ফোন লাগাও", "ফোন লাগান",
        "কল দাও", "কল করো", "কল কর", "কল দিন", "কল লাগাও", "কল লাগান"
    ).sortedByDescending { it.length }

    private val smsNouns = listOf(
        "মেসেজ", "ম্যাসেজ", "এসএমএস", "এস এম এস", "টেক্সট", "sms"
    ).sortedByDescending { it.length }

    private val smsVerbs = listOf(
        "পাঠিয়ে দাও", "পাঠিয়ে দিন", "পাঠাও", "পাঠান",
        "দাও", "দিন", "করো", "কর", "লিখো", "লেখো"
    ).sortedByDescending { it.length }

    // <নাম>কে [একটা] মেসেজ পাঠাও [যে] <লেখা>
    private val smsRegex = Regex(
        "^(.+?)\\s*-?কে\\s*(?:একটা\\s+|একটি\\s+)?" +
            "(?:${smsNouns.joinToString("|")})\\s*" +
            "(?:${smsVerbs.joinToString("|")})\\s*" +
            "(?:যে(?=[\\s,:]|$)|[:,])?\\s*(.*)$",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )

    fun parse(raw: String): Command {
        val text = raw.trim()
        if (text.isEmpty()) return Command(ActionType.UNKNOWN)

        // আগে SMS দেখি, কারণ মেসেজের ভেতরে "ফোন দাও" থাকতে পারে
        smsRegex.find(text)?.let { m ->
            val name = cleanName(m.groupValues[1])
            val message = m.groupValues[2].trim()
            if (name.isNotEmpty()) {
                return Command(ActionType.SMS, name = name, message = message)
            }
        }

        for (verb in callVerbs) {
            val idx = text.indexOf(verb)
            if (idx < 0) continue
            val before = text.substring(0, idx)
            val after = text.substring(idx + verb.length)
            val name = cleanName(if (before.isNotBlank()) before else after)
            if (name.isNotEmpty()) {
                return Command(ActionType.CALL, name = name)
            }
        }

        return Command(ActionType.UNKNOWN)
    }

    private fun cleanName(raw: String): String {
        var n = raw.trim().trim(',', '।', '.', ':')
        for (filler in listOf("একটা", "একটি")) {
            if (n.endsWith(filler)) n = n.removeSuffix(filler).trim()
        }
        n = n.removeSuffix("-কে").removeSuffix("কে").trim()
        return n
    }
}
