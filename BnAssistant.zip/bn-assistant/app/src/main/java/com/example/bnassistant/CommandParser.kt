package com.example.bnassistant

/**
 * কীওয়ার্ড দিয়ে বাংলা কমান্ড বোঝা — ফ্রি, ইন্টারনেট ছাড়াই চলে।
 * না বুঝলে ActionType.UNKNOWN ফেরত দেয়, তখন Claude API ব্যবহার হয়।
 */
object CommandParser {

    private fun normalize(raw: String): String = TextUtil.normalize(TextUtil.bnDigits(raw))

    private fun hasAny(t: String, vararg words: String): Boolean = words.any { t.contains(it) }

    // ------------------------------------------------------------ কল / SMS

    private val callVerbs = listOf(
        "ফোন দাও", "ফোন করো", "ফোন কর", "ফোন দিন", "ফোন লাগাও", "ফোন লাগান",
        "কল দাও", "কল করো", "কল কর", "কল দিন", "কল লাগাও", "কল লাগান"
    ).sortedByDescending { it.length }

    private val smsNouns = listOf(
        "মেসেজ", "ম্যাসেজ", "এসএমএস", "এস এম এস", "টেক্সট", "sms"
    ).sortedByDescending { it.length }

    private val smsVerbs = listOf(
        "পাঠিয়ে দাও", "পাঠিয়ে দিন", "পাঠাও", "পাঠান",
        "দাও", "দিন", "করো", "কর", "লিখো", "লেখো"
    ).sortedByDescending { it.length }

    private val smsRegex = Regex(
        "^(.+?)\\s*-?কে\\s*(?:একটা\\s+|একটি\\s+)?" +
            "(?:${smsNouns.joinToString("|")})\\s*" +
            "(?:${smsVerbs.joinToString("|")})\\s*" +
            "(?:যে(?=[\\s,:]|$)|[:,])?\\s*(.*)$",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )

    private fun cleanName(raw: String): String {
        var n = raw.trim().trim(',', '।', '.', ':')
        for (filler in listOf("একটা", "একটি")) {
            if (n.endsWith(filler)) n = n.removeSuffix(filler).trim()
        }
        n = n.removeSuffix("-কে").removeSuffix("কে").trim()
        return n
    }

    private fun parseSms(t: String): Command? {
        val m = smsRegex.find(t) ?: return null
        val name = cleanName(m.groupValues[1])
        if (name.isEmpty()) return null
        return Command(ActionType.SMS, name = name, message = m.groupValues[2].trim())
    }

    private fun parseCall(t: String): Command? {
        for (verb in callVerbs) {
            val idx = t.indexOf(verb)
            if (idx < 0) continue
            val before = t.substring(0, idx)
            val after = t.substring(idx + verb.length)
            val name = cleanName(if (before.isNotBlank()) before else after)
            if (name.isNotEmpty()) return Command(ActionType.CALL, name = name)
        }
        return null
    }

    private fun parseCallControl(t: String): Command? {
        if (t == "ধরো" || t == "ধর" ||
            hasAny(t, "কল ধরো", "ফোন ধরো", "কল ধর", "ফোন ধর", "কলটা ধরো", "ফোনটা ধরো",
                "কল রিসিভ", "ফোন রিসিভ", "রিসিভ করো", "কল তোলো", "ফোন তোলো")
        ) return Command(ActionType.ANSWER_CALL)

        if (t == "কেটে দাও" || t == "কেটে দিন" ||
            hasAny(t, "কল কেটে", "ফোন কেটে", "কলটা কেটে", "ফোনটা কেটে", "কল কাটো", "ফোন কাটো",
                "কল রিজেক্ট", "রিজেক্ট করো", "কল বন্ধ করো", "ফোন রেখে দাও", "কল রেখে দাও")
        ) return Command(ActionType.REJECT_CALL)
        return null
    }

    // ------------------------------------------------------------ ডিভাইস নিয়ন্ত্রণ

    private fun parseTorch(t: String): Command? {
        if (!hasAny(t, "টর্চ", "ফ্ল্যাশলাইট", "ফ্ল্যাশ লাইট", "ফ্লাশলাইট")) return null
        val off = hasAny(t, "নিভাও", "নিভিয়ে", "নিভান", "অফ", "বন্ধ")
        val on = hasAny(t, "জ্বালাও", "জ্বালিয়ে", "জ্বালান", "জ্বালা", "অন", "চালু", "চালাও")
        return Command(ActionType.TORCH, arg = if (off) "off" else if (on) "on" else "toggle")
    }

    private fun parseVolume(t: String): Command? {
        if (!hasAny(t, "ভলিউম", "আওয়াজ", "শব্দ", "সাউন্ড")) return null
        val arg = when {
            hasAny(t, "ফুল", "সর্বোচ্চ", "ম্যাক্স", "সবচেয়ে বেশি") -> "max"
            hasAny(t, "মিউট", "নীরব", "বন্ধ") -> "mute"
            hasAny(t, "বাড়াও", "বাড়ান", "বেশি", "বাড়িয়ে", "আপ") -> "up"
            hasAny(t, "কমাও", "কমান", "কম", "কমিয়ে", "ডাউন") -> "down"
            else -> ""
        }
        return if (arg.isEmpty()) null else Command(ActionType.VOLUME, arg = arg)
    }

    private fun parseMedia(t: String): Command? {
        val musicWord = hasAny(t, "গান", "মিউজিক", "সং")
        val arg = when {
            hasAny(t, "পরের গান", "পরেরটা", "পরের টা", "পরবর্তী", "নেক্সট") -> "next"
            hasAny(t, "আগের গান", "আগেরটা", "আগের টা", "প্রিভিয়াস", "পেছনের গান") -> "prev"
            musicWord && hasAny(t, "থামাও", "থামান", "থামিয়ে", "বন্ধ", "পজ") -> "pause"
            musicWord && hasAny(t, "চালাও", "চালান", "চালু", "প্লে", "শুরু") -> "play"
            else -> ""
        }
        return if (arg.isEmpty()) null else Command(ActionType.MEDIA, arg = arg)
    }

    private fun parseSettings(t: String): Command? {
        val action = hasAny(t, "চালু", "বন্ধ", "অন", "অফ", "খোলো", "সেটিং")
        if (!action) return null
        val arg = when {
            hasAny(t, "ওয়াইফাই", "ওয়াই ফাই", "ওয়াই-ফাই", "wifi") -> "wifi"
            hasAny(t, "ব্লুটুথ") -> "bluetooth"
            hasAny(t, "মোবাইল ডেটা", "মোবাইল ডাটা", "ইন্টারনেট") -> "data"
            else -> ""
        }
        return if (arg.isEmpty()) null else Command(ActionType.SETTINGS, arg = arg)
    }

    private fun parseGlobal(t: String): Command? {
        if (t.length > 30) return null
        val arg = when {
            hasAny(t, "স্ক্রিনশট", "স্ক্রিন শট", "স্ক্রীনশট") -> "screenshot"
            hasAny(t, "স্ক্রিন লক", "ফোন লক", "লক করো", "লক কর") -> "lock"
            hasAny(t, "নোটিফিকেশন") -> "notifications"
            hasAny(t, "রিসেন্ট", "সাম্প্রতিক") -> "recents"
            hasAny(t, "হোম") -> "home"
            hasAny(t, "পেছনে", "পিছনে", "ব্যাক") -> "back"
            else -> ""
        }
        return if (arg.isEmpty()) null else Command(ActionType.GLOBAL, arg = arg)
    }

    private val clickA = Regex("^(?:ক্লিক|টাচ|চাপ|টিপ|প্রেস)\\s*(?:করো|কর|দাও)?\\s+(.+)$")
    private val clickB = Regex("^(.+?)\\s*(?:-?এ|-?তে)?\\s*(?:ক্লিক|চাপ|টিপ|প্রেস)\\s*(?:করো|কর|দাও)$")
    private val typeRegex = Regex("^(?:টাইপ\\s*(?:করো|কর)|লেখো|লিখো|লিখে দাও|লেখ)\\s+(.+)$")

    private fun parseClickType(t: String): Command? {
        typeRegex.find(t)?.let { return Command(ActionType.TYPE, message = it.groupValues[1].trim()) }
        clickA.find(t)?.let { return Command(ActionType.CLICK, message = it.groupValues[1].trim()) }
        clickB.find(t)?.let { return Command(ActionType.CLICK, message = it.groupValues[1].trim()) }
        return null
    }

    private fun parseTimeQuery(t: String): Command? =
        if (hasAny(t, "সময় কত", "কয়টা বাজে", "কটা বাজে", "এখন কয়টা", "এখন কটা", "টাইম কত", "কয়টা বাজছে"))
            Command(ActionType.TIME) else null

    // ------------------------------------------------------------ সংখ্যা, সময়

    private val wordNumbers = mapOf(
        "এক" to 1, "দুই" to 2, "দুটো" to 2, "তিন" to 3, "চার" to 4, "পাঁচ" to 5, "ছয়" to 6,
        "ছয়" to 6, "সাত" to 7, "আট" to 8, "নয়" to 9, "দশ" to 10, "এগারো" to 11, "বারো" to 12,
        "পনেরো" to 15, "বিশ" to 20, "ত্রিশ" to 30
    )

    private fun numberIn(t: String): Int? {
        Regex("\\d+").find(t)?.value?.toIntOrNull()?.let { return it }
        for (tok in t.split(" ")) {
            val base = tok.removeSuffix("টায়").removeSuffix("টার").removeSuffix("টা").removeSuffix("টি")
            wordNumbers[base]?.let { return it }
        }
        return null
    }

    private fun parseDuration(t: String): Int {
        if (hasAny(t, "আধা ঘণ্টা", "আধা ঘন্টা", "আধ ঘণ্টা", "আধ ঘন্টা")) return 1800
        if (hasAny(t, "দেড় ঘণ্টা", "দেড় ঘন্টা")) return 5400
        val n = numberIn(t) ?: return 0
        return when {
            hasAny(t, "সেকেন্ড") -> n
            hasAny(t, "ঘণ্টা", "ঘন্টা") -> n * 3600
            hasAny(t, "মিনিট") -> n * 60
            else -> 0
        }
    }

    private fun parseTimer(t: String): Command? {
        if (!hasAny(t, "টাইমার")) return null
        val s = parseDuration(t)
        return if (s > 0) Command(ActionType.TIMER, seconds = s) else null
    }

    private fun parseAlarm(t: String): Command? {
        if (!hasAny(t, "অ্যালার্ম", "এলার্ম", "আলার্ম", "অ্যালারাম", "এলারাম", "এ্যালার্ম")) return null

        var hour: Int
        var minute = 0
        val colon = Regex("(\\d{1,2})\\s*[:.]\\s*(\\d{2})").find(t)
        if (colon != null) {
            hour = colon.groupValues[1].toInt()
            minute = colon.groupValues[2].toInt()
        } else {
            val nums = Regex("\\d+").findAll(t).map { it.value.toInt() }.toList()
            hour = nums.firstOrNull() ?: (numberIn(t) ?: return null)
            if (nums.size >= 2) minute = nums[1]
            if (hasAny(t, "সাড়ে")) minute = 30
            if (hasAny(t, "সওয়া", "সোয়া")) minute = 15
            if (hasAny(t, "পৌনে")) {
                hour = if (hour <= 1) 12 else hour - 1
                minute = 45
            }
        }

        when {
            hasAny(t, "সকাল", "ভোর") -> if (hour == 12) hour = 0
            hasAny(t, "দুপুর") -> if (hour in 1..5) hour += 12
            hasAny(t, "বিকাল", "বিকেল", "সন্ধ্যা") -> if (hour < 12) hour += 12
            hasAny(t, "রাত") -> if (hour in 6..11) hour += 12 else if (hour == 12) hour = 0
        }
        if (hour !in 0..23 || minute !in 0..59) return null
        return Command(ActionType.ALARM, hour = hour, minute = minute)
    }

    // ------------------------------------------------------------ অ্যাপ খোলা

    private val openA = Regex(
        "^(.+?)(?:\\s+(?:অ্যাপটা|অ্যাপটি|অ্যাপ|এপটা|এপ|app))?\\s*" +
            "(?:খোলো|খুলো|খোল|খুলুন|ওপেন করো|ওপেন কর|ওপেন|চালু করো|চালু কর|চালাও)$",
        RegexOption.IGNORE_CASE
    )
    private val openB = Regex("^(?:খোলো|খুলো|খুলুন|ওপেন করো|ওপেন)\\s+(.+)$", RegexOption.IGNORE_CASE)

    private fun parseOpenApp(t: String): Command? {
        val name = openA.find(t)?.groupValues?.get(1)?.trim()
            ?: openB.find(t)?.groupValues?.get(1)?.trim()
        if (name.isNullOrEmpty()) return null
        return Command(ActionType.OPEN_APP, name = name)
    }

    // ------------------------------------------------------------ মূল ফাংশন

    fun parse(raw: String): Command {
        val t = normalize(raw)
        if (t.isEmpty()) return Command(ActionType.UNKNOWN)

        // মেসেজের ভেতরে অন্য কমান্ডের শব্দ থাকতে পারে, তাই SMS সবার আগে
        parseSms(t)?.let { return it }
        parseCallControl(t)?.let { return it }
        parseCall(t)?.let { return it }
        parseTimer(t)?.let { return it }
        parseAlarm(t)?.let { return it }
        parseTorch(t)?.let { return it }
        parseVolume(t)?.let { return it }
        parseMedia(t)?.let { return it }
        parseTimeQuery(t)?.let { return it }
        parseSettings(t)?.let { return it }
        parseGlobal(t)?.let { return it }
        parseClickType(t)?.let { return it }
        parseOpenApp(t)?.let { return it }
        return Command(ActionType.UNKNOWN)
    }
}
